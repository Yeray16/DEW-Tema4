// Insertar automáticamente
tasks.forEach(task => {
  const states = document.querySelectorAll('.state');
  states.forEach(state => {
    if (state.id == task.state) {
      const div = document.createElement('div');
      div.classList.add("task", task.priority);
      div.id = "task_" + task.id;
      div.textContent = task.task;
      div.draggable = true;
      div.addEventListener('drop', drop);
      state.append(div);
    }
  })

});

document.querySelectorAll('.state').addEventListener('dragstart', (e) => {
  if(e.target.tagName === 'DIV') {
    e.dataTransfer.setData('text/plain', e.target.id);
    e.addEventListener('dragover', dragOver);
  }
})

function dragOver(e) {
  e.preventDefault();
}

function drop(e) {
  const div = document.getElementById(e.dataTransfer.getData('text/plain'));
  e.currentTarget.append(div);
}
